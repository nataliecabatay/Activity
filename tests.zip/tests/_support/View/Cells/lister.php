<?php foreach ($items as $item) : ?><?= $item ?> <?php endforeach ?>
